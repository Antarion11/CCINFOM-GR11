/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ccinfom.model;

import java.time.LocalDateTime;

public class StockLog {
    private int stockLogID;
    private int supplierID;
    private int productID;
    private int quantity;
    private String transactionType;
    private LocalDateTime transactionDate;

    public StockLog(int stockLogID, int supplierID, int productID, int quantity, String transactionType, LocalDateTime transactionDate) {
        this.stockLogID = stockLogID;
        this.supplierID = supplierID;
        this.productID = productID;
        this.quantity = quantity;
        this.transactionType = transactionType;
        this.transactionDate = transactionDate;
    }

    // --- Getters ---
    public int getStockLogID() { return stockLogID; }
    public int getSupplierID() { return supplierID; }
    public int getProductID() { return productID; }
    public int getQuantity() { return quantity; }
    public String getTransactionType() { return transactionType; }
    public LocalDateTime getTransactionDate() { return transactionDate; }
}