/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ccinfom.model;

public class Transport {
    private int transportID;
    private String contactPerson;
    private String phone;
    private String courierCompany;

    public Transport(int transportID, String contactPerson, String phone, String courierCompany) {
        this.transportID = transportID;
        this.contactPerson = contactPerson;
        this.phone = phone;
        this.courierCompany = courierCompany;
    }

    // --- Getters ---
    public int getTransportID() { return transportID; }
    public String getContactPerson() { return contactPerson; }
    public String getPhone() { return phone; }
    public String getCourierCompany() { return courierCompany; }
}