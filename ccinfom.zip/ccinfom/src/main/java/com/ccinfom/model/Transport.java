package com.ccinfom.model;

public class Transport {
    private int transportID;
    private String contactPerson;
    private String phone;
    private String courierCompany;

    public Transport(int transportID, String contactPerson, String phone, String courierCompany) {
        this.transportID = transportID;
        this.contactPerson = contactPerson;
        this.phone = phone;
        this.courierCompany = courierCompany;
    }

    // --- Getters ---
    public int getTransportID() { return transportID; }
    public String getContactPerson() { return contactPerson; }
    public String getPhone() { return phone; }
    public String getCourierCompany() { return courierCompany; }
}