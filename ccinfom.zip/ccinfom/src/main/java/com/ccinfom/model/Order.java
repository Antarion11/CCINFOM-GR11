/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ccinfom.model;

import java.time.LocalDate;

public class Order {
    private int orderID;
    private int customerID;
    private LocalDate orderDate;
    private String orderStatus;

    public Order(int orderID, int customerID, LocalDate orderDate, String orderStatus) {
        this.orderID = orderID;
        this.customerID = customerID;
        this.orderDate = orderDate;
        this.orderStatus = orderStatus;
    }

    // --- Getters ---
    public int getOrderID() { return orderID; }
    public int getCustomerID() { return customerID; }
    public LocalDate getOrderDate() { return orderDate; }
    public String getOrderStatus() { return orderStatus; }

    // --- Setters ---
    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }
}