/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.ccinfom.model;

public class Supplier {
    private int supplierID;
    private String companyName;
    private String contactPerson;
    private String phone;
    private String email;
    private String address;

    public Supplier(int supplierID, String companyName, String contactPerson, String phone, String email, String address) {
        this.supplierID = supplierID;
        this.companyName = companyName;
        this.contactPerson = contactPerson;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }

    // --- Getters ---
    public int getSupplierID() { return supplierID; }
    public String getCompanyName() { return companyName; }
    public String getContactPerson() { return contactPerson; }
    public String getPhone() { return phone; }
    public String getEmail() { return email; }
    public String getAddress() { return address; }
}