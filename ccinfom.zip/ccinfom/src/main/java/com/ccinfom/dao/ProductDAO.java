package com.ccinfom.dao;

import com.ccinfom.model.Product; 
import com.ccinfom.db.DBConnection; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * Data Access Object (DAO) for the 'Products' table
 * Handles all database operations related to the Product model
 */
public class ProductDAO {

    /**
     * Fetches all products from the database and returns them as a List of Product objects
     * @return A List of Product objects, or an empty list if none are found or an error occurs
     */
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        // SQL query must select all columns needed 
        String sql = "SELECT ProductID, ProductName, Manufacturer, Condition, AvailableQuantity, InventoryStatus FROM Products";
        
       
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {

                Product product = new Product(
                    rs.getInt("ProductID"),
                    rs.getString("ProductName"),
                    rs.getString("Manufacturer"),
                    rs.getString("Condition"),
                    rs.getInt("AvailableQuantity"),
                    rs.getString("InventoryStatus")
                );
                productList.add(product);
            }
        } catch (SQLException e) {
            System.err.println("Database Error: Could not fetch products.");
            e.printStackTrace();
        }
        return productList;
    }

    /**
     * Inserts a new Product into the Products table.
     * @param product The Product object containing the data to insert.
     * @return true if the insertion was successful, false otherwise.
     */
    public boolean addProduct(Product product) {
        // SQL INSERT statement with placeholders (?) for values
        String sql = "INSERT INTO Products (ProductName, Manufacturer, Condition, AvailableQuantity, InventoryStatus) VALUES (?, ?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            
            // Set the values for the placeholders in the correct order
            pstmt.setString(1, product.getProductName());
            pstmt.setString(2, product.getManufacturer());
            pstmt.setString(3, product.getCondition());
            pstmt.setInt(4, product.getAvailableQuantity());
            pstmt.setString(5, product.getInventoryStatus());

            int rowsAffected = pstmt.executeUpdate();
            
            return rowsAffected > 0;

        } catch (SQLException e) {
            System.err.println("Error adding product: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
        

    public boolean updateProduct(Product product) {
        String sql = "UPDATE Products SET ProductName = ?, Manufacturer = ?, `Condition` = ?, AvailableQuantity = ?, InventoryStatus = ? WHERE ProductID = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            // 1. Set values for the columns
            pstmt.setString(1, product.getProductName());
            pstmt.setString(2, product.getManufacturer());
            pstmt.setString(3, product.getCondition());
            pstmt.setInt(4, product.getAvailableQuantity());
            pstmt.setString(5, product.getInventoryStatus());

            // 2. Set the WHERE clause condition (the ProductID)
            pstmt.setInt(6, product.getProductID()); 

            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("Error updating product in database: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
  
}
