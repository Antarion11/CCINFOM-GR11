package com.ccinfom.dao;

import com.ccinfom.model.Supplier;
import com.ccinfom.db.DBConnection; // Assumes your connection class is here
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SupplierDAO {

    /**
     * Fetches all suppliers from the database.
     * @return A list of Supplier objects.
     */
    public List<Supplier> getAllSuppliers() {
        List<Supplier> supplierList = new ArrayList<>();
        String sql = "SELECT SupplierID, CompanyName, ContactPerson, Phone, Email, Address FROM Suppliers";
        
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Supplier supplier = new Supplier(
                    rs.getInt("SupplierID"),
                    rs.getString("CompanyName"),
                    rs.getString("ContactPerson"),
                    rs.getString("Phone"),
                    rs.getString("Email"),
                    rs.getString("Address")
                );
                supplierList.add(supplier);
            }
        } catch (SQLException e) {
            System.err.println("Database Error: Could not fetch suppliers.");
            e.printStackTrace();
        }
        return supplierList;
    }
}