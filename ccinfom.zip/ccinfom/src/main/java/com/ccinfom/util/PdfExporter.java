package com.ccinfom.util;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.JFrame;

public class PdfExporter {

    private static final Logger logger = Logger.getLogger(PdfExporter.class.getName());

    /**
     * Exports a SQL query ResultSet to a PDF file containing a table.
     * @param parentFrame The JFrame to display dialogs over.
     * @param reportTitle The title of the report and the PDF document.
     * @param rs The ResultSet containing the data to export. (MUST be before calling rs.next())
     * @param filePath The full path to save the PDF file (e.g., "reports/ReturnsAnalysis.pdf").
     * @param columnCount The number of columns to include in the PDF table.
     */
    public static boolean exportReportToPdf(JFrame parentFrame, String reportTitle, ResultSet rs, String filePath, int columnCount) {
        
        Document document = new Document(PageSize.A4.rotate());
        
        try {
            // Check if data exists before creating the file
            if (!rs.isBeforeFirst()) { 
                JOptionPane.showMessageDialog(parentFrame, 
                    "No data found for the selected criteria. Report will not be generated.", 
                    "No Data", JOptionPane.WARNING_MESSAGE);
                return false;
            }

            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();
            
            // 1. Add Title
            Font titleFont = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD, BaseColor.DARK_GRAY);
            Paragraph title = new Paragraph(reportTitle, titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            title.setSpacingAfter(20);
            document.add(title);

            // 2. Create Table
            PdfPTable table = new PdfPTable(columnCount);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);
            
            ResultSetMetaData metaData = rs.getMetaData();
            
            // 3. Add Table Headers
            Font headerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD, BaseColor.WHITE);
            BaseColor headerColor = new BaseColor(50, 50, 50); // Dark Gray
            
            for (int i = 1; i <= columnCount; i++) {
                PdfPCell header = new PdfPCell(new Phrase(metaData.getColumnLabel(i), headerFont));
                header.setHorizontalAlignment(Element.ALIGN_CENTER);
                header.setBackgroundColor(headerColor);
                table.addCell(header);
            }
            
            // 4. Add Table Data
            Font cellFont = new Font(Font.FontFamily.HELVETICA, 10);
            while (rs.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    PdfPCell cell = new PdfPCell(new Phrase(rs.getString(i), cellFont));
                    // Check if column is numeric to align right
                    if (metaData.getColumnType(i) == java.sql.Types.INTEGER || metaData.getColumnType(i) == java.sql.Types.DECIMAL) {
                         cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
                    } else {
                         cell.setHorizontalAlignment(Element.ALIGN_LEFT);
                    }
                    table.addCell(cell);
                }
            }
            
            document.add(table);
            
            // Success Message
            JOptionPane.showMessageDialog(parentFrame, 
                reportTitle + " successfully exported to:\n" + filePath, 
                "Export Success", JOptionPane.INFORMATION_MESSAGE);
            
            return true;

        } catch (DocumentException | java.io.FileNotFoundException e) {
            logger.severe("PDF Export Error: " + e.getMessage());
            JOptionPane.showMessageDialog(parentFrame, 
                "Error exporting PDF. Ensure the file is not open and the path is valid.\n" + e.getMessage(), 
                "Export Failed", JOptionPane.ERROR_MESSAGE);
            return false;
        } catch (SQLException e) {
             logger.severe("SQL Error during PDF generation: " + e.getMessage());
            JOptionPane.showMessageDialog(parentFrame, 
                "Error processing data for PDF: " + e.getMessage(), 
                "Export Failed", JOptionPane.ERROR_MESSAGE);
            return false;
        } finally {
            if (document.isOpen()) {
                document.close();
            }
        }
    }
}
