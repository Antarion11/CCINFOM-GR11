package com.ccinfom.model;

public class Customer {
    private int customerID;
    private String firstName;
    private String lastName;
    private String phoneNumber;
    private String email;
    private String address; 
    
    public Customer(int customerID, String firstName, String lastName, String phoneNumber, String email, String address) {
        this.customerID = customerID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.address = address;
    }

    // Getters 
    public int getCustomerID() { return customerID; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getPhone() { return phoneNumber; }
    public String getEmail() { return email; }
    public String getAddress() { return address; }

    public String getFullName() { return firstName + " " + lastName; }

    @Override
    public String toString() {
        return String.format("%d | %s %s | %s | %s | %s", 
                customerID, firstName, lastName, phoneNumber, email, address);
    }
}
